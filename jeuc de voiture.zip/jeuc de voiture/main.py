"""
coder par julien Gadotti

"""
#bon courage pour comprendre le code j'avais un peu la flemme de commenter mais aller voir les video de graen sur la creation d'un jeux avec pygame

import pygame
from module.game import Game
import time

pygame.init()

screen = pygame.display.set_mode((1280, 720))

background = pygame.image.load('img/background.jpg')
background = pygame.transform.scale(background, (1280, 720))

logo = pygame.image.load('img/logo.png')
logo = pygame.transform.scale(logo, (700, 700))

play_button = pygame.image.load('img/play.png')
play_button = pygame.transform.scale(play_button, (500, 500))
play_button_rect = play_button.get_rect()
play_button_rect.x = 380
play_button_rect.y = 200

game = Game(2)
action =[]
running = True
x_fleche = 900
y_fleche = -50
coordo= []
while running:


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()

        if game.jouer:
            game.update(screen, coordo)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    action.append('bas')
                    coordo.append((x_fleche,y_fleche, 4))
                    game.update(screen, coordo)
                    if x_fleche + 150 >= 1200:
                        y_fleche += 50
                        x_fleche = 900
                    else:
                        x_fleche += 50

                elif event.key == pygame.K_UP:
                    action.append('haut')
                    coordo.append((x_fleche,y_fleche, 3))
                    game.update(screen, coordo)
                    if x_fleche + 150 >= 1200:
                        y_fleche += 50
                        x_fleche = 900
                    else:
                        x_fleche += 50

                elif event.key == pygame.K_RIGHT:
                    action.append('droite')
                    coordo.append((x_fleche,y_fleche, 1))
                    game.update(screen, coordo)
                    if x_fleche + 150 >= 1200:
                        y_fleche += 50
                        x_fleche = 900
                    else:
                        x_fleche += 50

                elif event.key == pygame.K_LEFT:
                    action.append('gauche')
                    coordo.append((x_fleche,y_fleche, 2))
                    game.update(screen, coordo)
                    if x_fleche + 150 >= 1200:
                        y_fleche += 50
                        x_fleche = 900
                    else:
                        x_fleche += 50

                elif event.key == pygame.K_RETURN:
                    for elem in action:

                        if elem == "haut" and game.voiture.rect.y > 10:
                            if game.plateau[game.voiture.posy - 1][game.voiture.posx] != 1:
                                game.voiture.move_up()
                                game.update(screen, coordo)
                                time.sleep(0.5)
                            else:
                                game.game_over(screen)
                                game.update(screen, coordo)

                            if game.plateau[game.voiture.posy][game.voiture.posx] == 2:
                                game.winning(screen)
                                print("gage")
                                game.update(screen, coordo)

                        elif elem == "bas" and game.voiture.rect.y < 631:
                            if game.plateau[game.voiture.posy + 1][game.voiture.posx] != 1:
                                game.voiture.move_down()
                                game.update(screen, coordo)
                                time.sleep(0.5)
                            else:
                                game.game_over(screen)
                                game.update(screen, coordo)

                            if game.plateau[game.voiture.posy][game.voiture.posx] == 2:
                                game.winning(screen)
                                print("gage")
                                game.update(screen, coordo)

                        elif elem == "gauche" and game.voiture.rect.x > 235:
                            if game.plateau[game.voiture.posy][game.voiture.posx - 1] != 1:
                                game.voiture.move_left()
                                game.update(screen, coordo)
                                time.sleep(0.5)
                            else:
                                game.game_over(screen)
                                game.update(screen, coordo)

                            if game.plateau[game.voiture.posy][game.voiture.posx] == 2:
                                game.winning(screen)
                                print("gage")
                                game.update(screen, coordo)

                        elif elem == "droite" and game.voiture.rect.x < 856:
                            if game.plateau[game.voiture.posy][game.voiture.posx + 1] != 1:
                                game.voiture.move_right()
                                game.update(screen, coordo)
                                time.sleep(0.5)
                            else:
                                game.game_over(screen)
                                game.update(screen, coordo)
                            if game.plateau[game.voiture.posy][game.voiture.posx] == 2:
                                game.winning(screen)
                                print("gage")
                                game.update(screen, coordo)

                        print(game.voiture.posx, game.voiture.posy)
                        action = []
                        coordo = []
                        x_fleche = 900
                        y_fleche = -50

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if play_button_rect.collidepoint(event.pos):
                game.jouer = True
        else:
            screen.blit(background, (0, 0))
            screen.blit(logo, (300, -50))
            screen.blit(play_button, (play_button_rect.x, play_button_rect.y))

        pygame.display.update()