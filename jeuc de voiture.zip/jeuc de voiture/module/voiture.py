import pygame

class Voiture(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("img/voiture_droite.png")
        self.image = pygame.transform.scale(self.image, (70, 70))
        self.rect = self.image.get_rect()
        self.rect.x = 235
        self.rect.y = 10
        self.posx = 0
        self.posy = 0

    def move_right(self):
        self.rect.x += 69
        self.posx += 1
    def move_down(self):
        self.rect.y += 69
        self.posy += 1

    def move_left(self):
        self.rect.x -= 69
        self.posx -= 1

    def move_up(self):
        self.rect.y -= 69
        self.posy -= 1