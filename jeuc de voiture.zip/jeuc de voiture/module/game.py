from module.voiture import Voiture
from module.voleur import Voleur
import time
import pygame

pygame.init()
class Game:
    def __init__(self,niveaux):
        self.grille = pygame.image.load('img/grid.png')
        self.grille = pygame.transform.scale(self.grille, (700, 700))

        self.mur = pygame.image.load('img/brick.png')
        self.mur = pygame.transform.scale(self.mur, (70, 70))

        self.voleur = pygame.image.load("img/voleur.png")
        self.voleur = pygame.transform.scale(self.voleur, (150, 150))

        self.fleche = pygame.image.load("img/fleche.png")
        self.fleche = pygame.transform.scale(self.fleche, (150, 150))

        self.victoire = pygame.image.load("img/victoire.png")
        self.image_game_over = pygame.image.load('img/game_over.png')

        self.jouer = False
        self.voiture = Voiture()

        self.plateau = [[0, 1, 0, 0,1, 0, 1, 0, 1, 0],
                       [0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
                       [0, 1, 0, 0, 1, 0, 0, 0, 1, 0],
                       [0, 0, 0, 1, 0, 0, 1, 1, 1, 0],
                       [1, 0, 1, 1, 0, 0, 0, 0, 0, 0],
                       [0, 1, 1, 0, 0, 0, 0, 1, 0, 0],
                       [0, 0, 1, 0, 0, 0, 1, 1, 1, 1],
                       [0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
                       [0, 1, 0, 0, 1, 1, 0, 1, 0, 0],
                       [0, 1, 1, 0, 0, 0, 0, 1, 1, 2]]


    def game_over(self, screen):
        screen.fill((30, 40, 100))
        screen.blit(self.image_game_over, (400, 100))
        pygame.display.flip()
        self.voiture.rect.x = 235
        self.voiture.rect.y = 10
        self.voiture.posx = 0
        self.voiture.posy = 0
        time.sleep(2)

    def winning(self,screen):
        screen.fill((30, 40, 100))
        screen.blit(self.victoire, (400, 100))
        pygame.display.flip()
        self.voiture.rect.x = 235
        self.voiture.rect.y = 10
        self.voiture.posx = 0
        self.voiture.posy = 0
        time.sleep(2)
    def update(self,screen, coordo):
        screen.fill((30, 40, 100))
        screen.blit(self.grille, (230, 0))
        screen.blit(self.voiture.image, self.voiture.rect)
        screen.blit(self.voleur, (810, 590))
        self.affichage_fleche(screen, coordo)
        for y in range(len(self.plateau)):
            for x in range(len(self.plateau[y])):
                if self.plateau[y][x] == 1:
                    screen.blit(self.mur, (235+69*x, 5+69*y))

        pygame.display.flip()

    def affichage_fleche(self,screen, coordo):
        for cord in coordo:
            if cord[2] == 1:
                screen.blit(self.fleche, (cord[0], cord[1]))
            elif cord[2] == 2:
                screen.blit(pygame.transform.rotate(self.fleche, 180), (cord[0], cord[1]))
            elif cord[2] == 3:
                screen.blit(pygame.transform.rotate(self.fleche, 90), (cord[0], cord[1]))
            elif cord[2] == 4:
                screen.blit(pygame.transform.rotate(self.fleche, 270), (cord[0], cord[1]))