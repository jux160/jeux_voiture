import pygame

class Voleur(pygame.sprite.Sprite):
    def __init__(self,posx,posy):
        super().__init__()
        self.image = pygame.image.load("img/voleur.png")
        self.image = pygame.transform.scale(self.image, (70, 70))
        self.rect = self.image.get_rect()
        self.rect.x = 235 + posx * 70
        self.rect.y = 10 + posy * 70